export interface ModelChoice { 
     name: string;
     resultList: result[];

 }

 export interface result {
      premium:string;
    amount:string;
    type:string;
 }


 