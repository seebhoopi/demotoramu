import { Component ,OnInit, OnDestroy,HostListener} from '@angular/core';
import { Http, Headers, RequestOptions, Response, RequestMethod,Request } from '@angular/http';
import {AppService} from './app.service';
import { WindowRef } from './WindowRef';
import {FriendsService} from './friends-service';
import {FriendsList} from './friends-list';
import { ModelChoice } from "models/modelchoice";
import { UserModel } from "models/usermodel";
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  plscome: any;
  title = 'app works!';
        username='' ;
        model: any = {};
        display = {first:true, second:true};
        friends = [];
        subscription;
        selectedValue;
        modelChoice : ModelChoice[];
        resultList =[];
        userModel:UserModel;
        retrieveValues;
        selectedDeviceObj;
        values:any;
    appCache = window.applicationCache;
        
        constructor(private http: Http,private appService:AppService,private winRef: WindowRef
        ,private _friendsService:FriendsService) { 
           window.applicationCache.addEventListener('updateready', this.onUpdateReady);
           window.applicationCache.addEventListener('error', this.onError);
        }

onUpdateReady() {
  
  window.applicationCache.swapCache();
  alert('onUpdateReady found new version!');
}

onError() {

  if (navigator.onLine == true) { //If the user is connected to the internet.
                    alert("Error - Please contact the website administrator if this problem consists.");
                } else {
                    alert("You aren't connected to the internet. Some things might not be available.");
                }

  alert(' onErrorfound new version!');
}

// @HostListener("applicationCache:updateready", [])
// updateready() {

//   console.log("coming here applicationCache");
//  //we'll do some stuff here when the window is scrolled
// }


// function onUpdateReady() {
//   alert('found new version!');
// }

// window.applicationCache.addEventListener('updateready', onUpdateReady);

// if (window.applicationCache.status === window.applicationCache.UPDATEREADY) {
//   onUpdateReady();
// }


// @HostListener("applicationCache:error", [])
// onError() {

//   console.log("coming error here applicationCache");
//  //we'll do some stuff here when the window is scrolled
// }
// window.applicationCache.addEventListener():any
// {
//   return null;
// }
// appCache.addEventListener(){
// return;
// }
      clearAll()
      {
        
        this.appService.clearLocalStorage();
        this.retrieveValues=[];
        
      }
      onSubmit()
      {

            let x: UserModel = {
              name:this.username,
              userModelChoice: this.selectedDeviceObj
            }

          this.appService.storeObjectinLocalStorage(x);
                  
          this.username="";
      }

      onRetrieve()
      {


         this.retrieveValues =this.appService.getAllLocalStorageValues();
         this.plscome = this.retrieveValues;
          
        
      }
  
      onChangeObj(newObj) {
        
        this.selectedDeviceObj = newObj;

        this.resultList = newObj.resultList;
        
      }
    loadData(){
    


        this.appService.getJson()
                .subscribe(
                    data => {
                      
                      this.model = data.text()
                      
                    },
                    error => {
                      console.log(error);
                    });


            this.appService.getMultiChoice()
                        .subscribe(
                            data => {
                              this.modelChoice=data as ModelChoice[];
                              this.selectedDeviceObj = this.modelChoice[0];
                              
                              
                            },
                            error => {
                              console.log(error);
                            });

          //  this.modelChoice = this.appService.getMultiChoice();

         

      }

      ngOnInit(){
        this.loadData();
      }
      
      ngOnDestroy(){
        this.subscription.unsubscribe();
        
      }




        //  appCache.addEventListener("updateready", function(event) {
        //         alert ("New Content Available");
        //     	appCache.swapCache();
        //         location.reload(true);
        //     }, false);
        //     appCache.addEventListener("error", function(event) {
        //         if (navigator.onLine == true) { //If the user is connected to the internet.
        //             alert("Error - Please contact the website administrator if this problem consists.");
        //         } else {
        //             alert("You aren't connected to the internet. Some things might not be available.");
        //         }
        //     }, false);

}




